/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_GRAMMARTREE_TAB_H_INCLUDED
# define YY_YY_GRAMMARTREE_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    CHAR = 258,
    INT = 259,
    ID = 260,
    RELOP = 261,
    TYPE = 262,
    FLOAT = 263,
    GOWHERE = 264,
    STRING = 265,
    STRUCT = 266,
    DPLUS = 267,
    LP = 268,
    RP = 269,
    LC = 270,
    RC = 271,
    LB = 272,
    RB = 273,
    SEMI = 274,
    COMMA = 275,
    DOT = 276,
    PLUS = 277,
    MINUS = 278,
    STAR = 279,
    DIV = 280,
    MOD = 281,
    ASSIGNOP = 282,
    PLUSASSIGNOP = 283,
    MINUSASSIGNOP = 284,
    STARASSIGNOP = 285,
    DIVASSIGNOP = 286,
    MODASSIGNOP = 287,
    AND = 288,
    OR = 289,
    YH = 290,
    NOT = 291,
    AUTOPLUS = 292,
    AUTOMINUS = 293,
    IF = 294,
    ELSE = 295,
    WHILE = 296,
    FOR = 297,
    RETURN = 298,
    COLON = 299,
    DEFAULT = 300,
    CONTINUE = 301,
    BREAK = 302,
    VOID = 303,
    SWITCH = 304,
    CASE = 305,
    EXT_DEF_LIST = 306,
    EXT_VAR_DEF = 307,
    FUNC_DEF = 308,
    FUNC_DEC = 309,
    EXT_DEC_LIST = 310,
    PARAM_LIST = 311,
    PARAM_DEC = 312,
    VAR_DEF = 313,
    DEC_LIST = 314,
    DEF_LIST = 315,
    COMP_STM = 316,
    STM_LIST = 317,
    EXP_STMT = 318,
    IF_THEN = 319,
    IF_THEN_ELSE = 320,
    ARRAY_LIST = 321,
    ARRAY_ID = 322,
    FUNC_CALL = 323,
    ARGS = 324,
    FUNCTION = 325,
    PARAM = 326,
    ARG = 327,
    CALL = 328,
    LABEL = 329,
    GOTO = 330,
    JLT = 331,
    JLE = 332,
    JGT = 333,
    JGE = 334,
    EQ = 335,
    NEQ = 336,
    FOR_DEC = 337,
    STRUCT_DEF = 338,
    STRUCT_DEC = 339,
    STRUCT_TAG = 340,
    EXP_ELE = 341,
    SWITCH_STMT = 342,
    CASE_STMT = 343,
    DEFAULT_STMT = 344,
    EXP_ARRAY = 345,
    EXT_STRUCT_DEF = 346,
    ARRAY_DEC = 347,
    AUTOPLUS_L = 348,
    AUTOPLUS_R = 349,
    AUTOMINUS_L = 350,
    AUTOMINUS_R = 351,
    UMINUS = 352,
    LOWER_THEN_ELSE = 353
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 15 "grammarTree.y" /* yacc.c:1909  */

	int    type_int;
        char   type_char[5];
	float  type_float;
	char  type_gowhere[100];//zijitianjiade 
	char   type_id[32];
        char   type_string[32];
        char   struct_name[32];
	struct ASTNode *ptr;

#line 164 "grammarTree.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_GRAMMARTREE_TAB_H_INCLUDED  */
