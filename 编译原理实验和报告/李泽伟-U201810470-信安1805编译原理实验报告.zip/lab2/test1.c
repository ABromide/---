int f2(int a,int b)//1
{//2
    gowhere h1;//3
    //h1=~~123;//4
    int c;//5
    int b;//6
    return 1;//7
}
