int a, b, c;
float m, n;
char i;
gowhere beijin;
int fibo (int a){
if(a==l||a==2) return l;
return fibo (a-1 )+fibo ( a-2);
}
int main() 
{int m, n,i,h
gowhere beijin;//adawdawdaw
m=read () ;
i=1;
h=i^i;
beijin=~a;
while (i<=m)/*ihlll*/
{
n=fibo (i) ;write (n) ;i=i+l;}
return l;}


