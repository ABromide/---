int a,b,c;
char arr[10];
float m,n;
struct node{
    int a;
    int b;
};
int main()
{
    int m, n, i;
    float f;
    char ch;
    arr[1] = ch;
    if(a == 1) {
        m = 1;
    }
    else {
        m = 2;
    }
    while(i < m) {
        i++;
    }
    for(i = 1; i < n; i++) {
        f = 0.5;
    }
    return 1;
}