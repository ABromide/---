int a,b,c;
// int arr[10][10];
struct node{
    int a;
    int b;
};
// struct node T;

int fibo(){
    struct node T;
    int j;
    T.b = 4;
    j = T.b;
    // write(j);
    return 0;
}

int main()
{
    int i;
    fibo();
    return 0;
}