#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#include <sys/ioctl.h>
#define BUFF_SIZE 2000
/* header files copied from tlsserver.c file */
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <netdb.h>
#include <unistd.h>
/*libraries for authentication */
#include <shadow.h>
#include <crypt.h>
/* define HOME to be dir for key and cert files... */
#define HOME	"./cert_server/"
/* Make these what you want for cert & key files */
#define CERTF	HOME"server.crt"
#define KEYF	HOME"server.key"
#define CACERT	HOME"ca.crt"

#define USER_SIZE 200
#define PSW_SIZE 200

#define CHK_NULL(x)	if ((x)==NULL) exit (1)
#define CHK_ERR(err,s)	if ((err)==-1) { perror(s); exit(1); }
#define CHK_SSL(err)	if ((err)==-1) { ERR_print_errors_fp(stderr); exit(2); }
int authenticateClient(SSL* ssl, int newsock) {
  char username[BUFF_SIZE];
  char password[BUFF_SIZE];
  char recvBuff[BUFF_SIZE];
  bzero(recvBuff, BUFF_SIZE);
  memset(&username, 0x00, sizeof(username));
  memset(&password, 0x00, sizeof(password));
  
  int len;
  len = SSL_read(ssl, recvBuff, BUFF_SIZE-1);
  recvBuff[len] = '\0';
  printf("Server received the following string : %s\n", recvBuff);
  char* pch;
  pch = strtok(recvBuff, "$");
  if (pch != NULL) {
     strcpy(username, pch);
     pch = strtok(NULL, "$");
  } 
  if (pch != NULL) {
    strcpy(password, pch);
  }
  printf("user:%s pass:%s\n",username,password);
  struct spwd *pw;
  char *epasswd;
  pw = getspnam(username);
  if (pw == NULL) {
   printf("No password for the given user name\n");
   return -1;
  }
  printf("Given user name: %s\n", username);
  printf("Given password: %s\n", password);
  printf("Login name: %s\n", pw->sp_namp);
  printf("Passwd : %s\n", pw->sp_pwdp);
  epasswd = crypt(password, pw->sp_pwdp);
  char sendNegResp[] = "not-ok-auth";
  char sendPosResp[] = "auth$ok";

 if (strcmp(epasswd, pw->sp_pwdp)) {
   printf("Password entered doesn't match with correct password\n");
   SSL_write(ssl, sendNegResp, strlen(sendNegResp));
   return -1;
  }
  SSL_write(ssl, sendPosResp, strlen(sendPosResp));
  return 1;
}
void closeSSLAndSocket(SSL *ssl, int newsock) {
   if (ssl != NULL) {
      SSL_shutdown(ssl);
      SSL_free(ssl);
   }
   close(newsock);
}
int setupTCPServer();	// Defined in Listing 19.10
int createTunDevice() {
   int tunfd;
   struct ifreq ifr;
   memset(&ifr, 0, sizeof(ifr));

   ifr.ifr_flags = IFF_TUN | IFF_NO_PI;

   tunfd = open("/dev/net/tun", O_RDWR);
   int ret=ioctl(tunfd, TUNSETIFF, &ifr);
   if (ret == -1) {
		printf("Setup TUN interface by ioctl failed! (%d: %s)\n", errno, strerror(errno));
		return -1;
	}
   printf("Created a tun device with the name: %s\n", ifr.ifr_name);
   return tunfd;
}
SSL* SSLLibInit() {
SSL_METHOD *meth;
	SSL_CTX *ctx;
	SSL *ssl;
	int err;

	// Step 0: OpenSSL library initialization 
	// This step is no longer needed as of version 1.1.0.
	SSL_library_init();			/* ΪSSL���ؼ��ܺ͹�ϣ�㷨 */   
	SSL_load_error_strings();	/* Ϊ�˸��Ѻõı��������ش�����������ַ��� */
	SSLeay_add_ssl_algorithms();

	// Step 1: SSL context initialization
	meth = SSLv23_server_method();//ʹ��SSLv23�ķ���������֧��SSLv2,SSLv3�Լ�TLSv1������hello��Ϣ 
	ctx = SSL_CTX_new(meth);//SSL_CTX_new������SSL_METHOD�ṹ����Ϊ�������������ҷ���SSL_CTX�ṹ�� 
	
   //����SSL_CTX_set_verify��������������SSL_CTX�ṹ�е���֤��ǣ�
   //������������������һ��ָ����֤���̵Ļص����������ص������������ΪNULL��ζ�����ڽ�Ĭ�ϵ���֤��ʽ����
	SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);
	//SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
	
	
	SSL_CTX_load_verify_locations(ctx, CACERT, NULL);//������Ҫ����CA֤�� 

	// Step 2: Set up the server certificate and private key
	if (SSL_CTX_use_certificate_file(ctx, CERTF, SSL_FILETYPE_PEM) <= 0) { 
		ERR_print_errors_fp(stderr);//��������һ��֤�鵽һ��SSL_CTX�ṹ��
		exit(3);
	}
	if (SSL_CTX_use_PrivateKey_file(ctx, KEYF, SSL_FILETYPE_PEM) <= 0) {
		ERR_print_errors_fp(stderr);//����˽Կ��SSL�ṹ����SSL_CTX�ṹ�� 
		exit(4);
	}
	if (!SSL_CTX_check_private_key(ctx)) {
		fprintf(stderr, "Private key does not match the certificate public key\n");
		exit(5);
	}
	// Step 3: Create a new SSL structure for a connection
	ssl = SSL_new(ctx);//����SSL
	return ssl;
}
void tunSelected(int tunfd, int sockfd, SSL *ssl) {
    int  len;
    char buff[BUFF_SIZE];
    bzero(buff, BUFF_SIZE);
	printf("Got a packet from TUN\n");
    len = read(tunfd, buff, BUFF_SIZE);
    buff[len] = '\0';
    SSL_write(ssl, buff, len);
}
void checkforTermination(char buff[], SSL* ssl, int sockfd) {
    if ((buff[0] != '\0') && strstr(buff, "terminate$$connection") != NULL) {
        printf("Received a request to terminate the connection\n");
        closeSSLAndSocket(ssl, sockfd); 
        exit(0);
    }
}
void socketSelected(int tunfd, int sockfd, SSL *ssl) {
   int  len;
   char buff[BUFF_SIZE];
   printf("Got a packet from the tunnel\n");
   char *ptr = buff;
   bzero(buff, BUFF_SIZE);
   len = SSL_read(ssl, buff, BUFF_SIZE);
   buff[len] = '\0';
   checkforTermination(buff, ssl, sockfd); 
   write(tunfd, buff, len);
}
int setupTCPServer(){
	struct sockaddr_in sa_server;
	int listen_sock;
	//socket()������������socket��
	listen_sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	CHK_ERR(listen_sock, "socket");
	memset(&sa_server, '\0', sizeof(sa_server));
	sa_server.sin_family = AF_INET;
	sa_server.sin_addr.s_addr = INADDR_ANY;
	sa_server.sin_port = htons(4433);
	//ʹ��bind�������˶˿ں͵�ַ���ڵ���listen�����󣬾Ϳ��Դ������Կͻ��˵�TCP/IP������  
	int err = bind(listen_sock, (struct sockaddr *) &sa_server, sizeof(sa_server));
 
	CHK_ERR(err, "bind");
	err = listen(listen_sock, 5);// �ȴ�����Ϊ5 
	CHK_ERR(err, "listen");
	printf("Created a tcp server listening on port: 4433 for any IP\n");
	return listen_sock;
}
void processRequest(int tunfd, SSL* ssl, int sockfd){
	while(1) {
     fd_set readFDSet;

     FD_ZERO(&readFDSet);
     FD_SET(sockfd, &readFDSet);
     FD_SET(tunfd, &readFDSet);
     select(FD_SETSIZE, &readFDSet, NULL, NULL, NULL);

     if (FD_ISSET(tunfd,  &readFDSet)) tunSelected(tunfd, sockfd, ssl);
     if (FD_ISSET(sockfd, &readFDSet)) socketSelected(tunfd, sockfd, ssl);
   }
}
int main()
{
	//������������ 
	int tunfd, sockfd;
    tunfd  = createTunDevice();
   //ssl��ʼ�� 
	SSL *ssl = SSLLibInit();
	//tcp���ӽ��� 
	struct sockaddr_in sa_client;
	size_t client_len = sizeof(struct sockaddr_in);
	int listen_sock = setupTCPServer();
 
	fprintf(stderr, "listen_sock = %d\n", listen_sock);
	while (1) {
		//��һ������Ϊ�������û����������tcp���� 
		int sock = accept(listen_sock, (struct sockaddr *) &sa_client, &client_len);
		fprintf(stderr, "sock = %d\n", sock);
		if (sock == -1) {
			fprintf(stderr, "Accept TCP connect failed! (%d: %s)\n", errno, strerror(errno));
			continue;
		}
		if (fork() == 0) {	// The child process
			close(listen_sock);
			
			char username[USER_SIZE];
		    char password[PSW_SIZE];
		    memset(username,0,USER_SIZE);
		    memset(password,0,PSW_SIZE);
		    
			SSL_set_fd(ssl, sock);//��SSL��TCP socket����
			int err = SSL_accept(ssl);//������SSL����,���� 

			fprintf(stderr, "SSL_accept return %d\n", err);
			CHK_SSL(err);
			printf("SSL connection established!\n");
			
			if (authenticateClient(ssl, sock) != 1) {
		          closeSSLAndSocket(ssl, sock);
		          printf("Cleared socket and ssl structures.. ENd of child process\n");
		          return 0;
       		}
	       printf("CLient authentication is successful and ready to receive data on the channel\n");
	       processRequest(tunfd, ssl, sock);
	       closeSSLAndSocket(ssl, sock);
	       printf("Cleared socket and ssl structures.. End of child process\n");
	       return 0;
		} else {	// The parent process
			close(sock);
		}
	}
}


